SRF02 Arduino Library Version 1.4
(C) 2008-2012 Dirk Grappendorf (www.grappendorf.net)
================================================================================


Installation
------------

Unzip into your <Path to Arduino>/libraries directory.
Start Arduino and select File->Sketchbook->Examples->Library SRF02->SRF02
from the Menu.


License
-------

This library is free software; you can redistribute it and/or modify it under
the terms of the GNU LESSER GENERAL PUBLIC LICENSE Version 3.0.

This library is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See GNU LESSER GENERAL PUBLIC LICENSE Version 3.0
for more details.

You should have received a copy of the GNU LESSER GENERAL PUBLIC LICENSE Version 3.0 
along with this library; if not, you can get an online copy at
http://www.gnu.org/licenses/lgpl.html
